execute if entity @a[name=TheobaldTheBot,tag=!fire] run tag TheobaldTheBot add addfire
tag TheobaldTheBot remove fire
execute if entity @a[name=TheobaldTheBot,tag=addfire] run tag TheobaldTheBot add fire
tag TheobaldTheBot remove addfire

execute if entity @a[name=TheobaldTheBot,tag=fire] run title @a actionbar [{"text":"ALLOW FIRE ","color":"yellow"},{"text":"ON", "color":"green"}]
execute if entity @a[name=TheobaldTheBot,tag=!fire] run title @a actionbar [{"text":"ALLOW FIRE ","color":"yellow"},{"text":"OFF", "color":"red"}] 