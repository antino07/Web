scoreboard objectives add hitcd dummy
scoreboard objectives add strafecd dummy
scoreboard objectives add hit minecraft.custom:damage_dealt
scoreboard objectives add difficulty dummy
scoreboard objectives add direction dummy
scoreboard objectives add crystal dummy
scoreboard objectives add crystalcd dummy
scoreboard objectives add despawn dummy
scoreboard objectives add pops minecraft.used:minecraft.totem_of_undying
scoreboard objectives add death deathCount
scoreboard objectives add Score dummy
scoreboard objectives add x dummy
scoreboard objectives add y dummy
scoreboard objectives add z dummy
scoreboard objectives add oldx dummy
scoreboard objectives add oldy dummy
scoreboard objectives add oldz dummy
scoreboard objectives add vx dummy
scoreboard objectives add vy dummy
scoreboard objectives add vz dummy
scoreboard objectives add fx dummy
scoreboard objectives add fz dummy
scoreboard objectives add rx dummy
scoreboard objectives add rz dummy

player TheobaldTheBot spawn at 8.50 13.00 14.50 facing 180 0
scoreboard players set @a carpet 0
schedule function practicebot:reset 5t
schedule function practicebot:testcarpet 5t
title @a actionbar {"text":"PRACTICE BOT LOADED","color":"yellow"}