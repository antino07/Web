execute if entity @a[name=TheobaldTheBot,tag=!diamond] run tag TheobaldTheBot add adddiamond
tag TheobaldTheBot remove diamond
tag TheobaldTheBot remove neth
execute if entity @a[name=TheobaldTheBot,tag=adddiamond] run tag TheobaldTheBot add diamond
execute if entity @a[name=TheobaldTheBot,tag=!adddiamond] run tag TheobaldTheBot add neth
tag TheobaldTheBot remove adddiamond
tag TheobaldTheBot remove naked

execute if entity @a[name=TheobaldTheBot,tag=diamond] run title @a actionbar [{"text":"GEAR CHANGED TO ","color":"yellow"},{"text":"DIAMOND", "color":"aqua"}]
execute if entity @a[name=TheobaldTheBot,tag=!diamond] run title @a actionbar [{"text":"GEAR CHANGED TO ","color":"yellow"},{"text":"NETHERITE", "color":"dark_purple"}]

function practicebot:botgear/crystalgear