setblock 8 61 8 minecraft:stone_button[face=floor,facing=north,powered=false] replace
setblock 7 60 8 minecraft:sea_lantern
setblock 8 60 9 minecraft:sea_lantern
setblock 9 60 8 minecraft:sea_lantern
setblock 8 60 7 minecraft:sea_lantern