scoreboard players set TheobaldTheBot direction 0
execute if predicate practicebot:random run scoreboard players add TheobaldTheBot direction 1
scoreboard players set TheobaldTheBot strafecd 5