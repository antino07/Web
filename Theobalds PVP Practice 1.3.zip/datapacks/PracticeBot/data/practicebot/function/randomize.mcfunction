tag TheobaldTheBot remove tempcrit
tag TheobaldTheBot remove tempjreset
tag TheobaldTheBot remove tempshield
tag TheobaldTheBot remove tempstap
tag TheobaldTheBot remove tempstrafe

execute as TheobaldTheBot if entity @s[tag=crit] if predicate practicebot:random run tag TheobaldTheBot add tempcrit
execute as TheobaldTheBot if entity @s[tag=jreset] if predicate practicebot:random run tag TheobaldTheBot add tempjreset
execute as TheobaldTheBot if entity @s[tag=shield] if predicate practicebot:random run tag TheobaldTheBot add tempshield
execute as TheobaldTheBot if entity @s[tag=stap] if predicate practicebot:random run tag TheobaldTheBot add tempstap
execute as TheobaldTheBot if entity @s[tag=strafe] if predicate practicebot:random run tag TheobaldTheBot add tempstrafe

scoreboard players set TheobaldTheBot randomcd 9
execute if predicate practicebot:random run scoreboard players add TheobaldTheBot randomcd 5