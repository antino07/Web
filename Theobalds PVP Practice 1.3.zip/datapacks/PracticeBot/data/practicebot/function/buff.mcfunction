effect give @a fire_resistance 1 1 true
effect give @a strength 1 1 true
effect give @a speed 1 1 true
