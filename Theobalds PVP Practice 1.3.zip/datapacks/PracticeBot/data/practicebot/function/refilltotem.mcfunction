execute unless entity @s[tag=shield] run item replace entity @s hotbar.8 with totem_of_undying
execute as TheobaldTheBot if entity @s[tag=shield] if score @s difficulty matches 0..1 run item replace entity @s hotbar.8 with shield[enchantments={levels:{unbreaking:3,mending:1}},minecraft:unbreakable={}]
item replace entity @s weapon.offhand with totem_of_undying