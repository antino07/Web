player TheobaldTheBot stop
player TheobaldTheBot move forward
player TheobaldTheBot unsprint
player TheobaldTheBot attack

execute as TheobaldTheBot if entity @s[tag=sword,tag=shield] if score @p[name=!TheobaldTheBot] shieldcount matches 1.. if score @s difficulty matches 2.. run player TheobaldTheBot hotbar 4
execute as TheobaldTheBot if entity @s[tag=sword,tag=shield] if score @p[name=!TheobaldTheBot] shieldcount matches 1.. if score @s difficulty matches 2.. run schedule function practicebot:hotbar1 2t
scoreboard players set @a[name=!TheobaldTheBot] shieldcount 0

scoreboard players set TheobaldTheBot hitcd 11
execute as TheobaldTheBot if entity @s[tag=shield,tag=sword] run schedule function practicebot:usecontinuous 2t