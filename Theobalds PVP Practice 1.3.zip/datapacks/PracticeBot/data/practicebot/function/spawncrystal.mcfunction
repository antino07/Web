kill @e[type=marker]
scoreboard players set TheobaldTheBot direction 0
execute if predicate practicebot:random run scoreboard players add TheobaldTheBot direction 1

execute if score TheobaldTheBot direction matches 0 run summon minecraft:marker ^1.5 ^ ^3 {CustomName:"{\"text\":\"crystal\"}"}
execute if score TheobaldTheBot direction matches 1 run summon minecraft:marker ^-1.5 ^ ^3 {CustomName:"{\"text\":\"crystal\"}"}
execute at @e[type=marker,name=crystal] align xyz run tp @e[limit=1,sort=nearest,type=marker] ~.5 61 ~.5
execute at @e[type=marker,name=crystal] run fill ~ 61 ~ ~ 61 ~ obsidian replace air
execute at @e[type=marker,name=crystal] run fill ~ 61 ~ ~ 61 ~ obsidian replace fire


schedule function practicebot:marker 7t