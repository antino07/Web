#title @a times 0t 60t 30t
#title @a title [{"text":"YOU KILLED THE BOT!","color":"green"}]
#function practicebot:reset

#tellraw @a {"text": "<TheobaldTheBot> reported"}