execute if entity @a[name=TheobaldTheBot,tag=!crit] run tag TheobaldTheBot add addcrit
tag TheobaldTheBot remove crit
execute if entity @a[name=TheobaldTheBot,tag=addcrit] run tag TheobaldTheBot add crit
tag TheobaldTheBot remove addcrit

execute as TheobaldTheBot if entity @s[tag=crit] run tag @s add tempcrit
execute as TheobaldTheBot if entity @s[tag=!crit] run tag @s remove tempcrit

execute if entity @a[name=TheobaldTheBot,tag=crit] run title @a actionbar [{"text":"CRITTING ","color":"yellow"},{"text":"ON", "color":"green"}]
execute if entity @a[name=TheobaldTheBot,tag=!crit] run title @a actionbar [{"text":"CRITTING ","color":"yellow"},{"text":"OFF", "color":"red"}] 