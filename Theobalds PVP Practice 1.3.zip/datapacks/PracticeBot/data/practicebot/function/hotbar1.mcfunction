player TheobaldTheBot hotbar 1
scoreboard players set TheobaldTheBot hitcd 13