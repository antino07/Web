execute at @e[name=crystal,type=marker] unless entity @e[type=end_crystal,distance=..2] run summon end_crystal ~ ~1 ~ {ShowBottom:false}
scoreboard players add @e[name=crystal,type=marker] crystal 1
schedule function practicebot:marker 4t