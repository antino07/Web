execute as TheobaldTheBot if entity @s[tag=diamond] run function practicebot:botgear/diamondgear
execute as TheobaldTheBot if entity @s[tag=!diamond] run function practicebot:botgear/nethgear

execute as TheobaldTheBot if entity @s[tag=shield,tag=crystal] if score @s difficulty matches 0..1 run item replace entity @s hotbar.8 with shield[enchantments={levels:{unbreaking:3,mending:1}},minecraft:unbreakable={}]
execute as TheobaldTheBot if entity @s[tag=sword] run item replace entity @a[scores={kitloaded=0}] weapon.offhand with air
execute as TheobaldTheBot if entity @s[tag=shield,tag=sword] run item replace entity @a[scores={kitloaded=0}] weapon.offhand with shield[minecraft:unbreakable={}]