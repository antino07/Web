execute if entity @a[name=TheobaldTheBot,tag=!diamond] run tag TheobaldTheBot add adddiamond
tag TheobaldTheBot remove diamond
execute if entity @a[name=TheobaldTheBot,tag=adddiamond] run tag TheobaldTheBot add diamond
tag TheobaldTheBot remove adddiamond

execute if entity @a[name=TheobaldTheBot,tag=diamond] run title @a actionbar [{"text":"GEAR CHANGED TO ","color":"yellow"},{"text":"DIAMOND", "color":"aqua"}]
execute if entity @a[name=TheobaldTheBot,tag=!diamond] run title @a actionbar [{"text":"GEAR CHANGED TO ","color":"yellow"},{"text":"NETHERITE", "color":"#AAAAAA"}]

function practicebot:botgear/crystalgear