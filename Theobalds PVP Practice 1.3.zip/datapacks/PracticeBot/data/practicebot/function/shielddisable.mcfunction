scoreboard players set TheobaldTheBot shieldcd 100
#advancement revoke @a[name=!TheobaldTheBot] only practicebot:shielddisable
#say blocked