tp @a -66.0 141 -543.0
scoreboard players set TheobaldTheBot holeused 1