gamemode survival TheobaldTheBot
execute as TheobaldTheBot if entity @s[tag=naked] run gamemode adventure @a[name=!TheobaldTheBot]
execute as TheobaldTheBot if entity @s[tag=!naked] run gamemode survival @a[name=!TheobaldTheBot]