player TheobaldTheBot stop
execute if entity @a[name=TheobaldTheBot,tag=!strafe] run tag TheobaldTheBot add addstrafe
tag TheobaldTheBot remove strafe
execute if entity @a[name=TheobaldTheBot,tag=addstrafe] run tag TheobaldTheBot add strafe
tag TheobaldTheBot remove addstrafe

execute if entity @a[name=TheobaldTheBot,tag=strafe] run title @a actionbar [{"text":"STRAFING ","color": "yellow"},{"text":"ON", "color":"green"}]
execute if entity @a[name=TheobaldTheBot,tag=!strafe] run title @a actionbar [{"text":"STRAFING ","color": "yellow"},{"text":"OFF", "color":"red"}]

execute as TheobaldTheBot if entity @s[tag=strafe] run tag @s add tempstrafe
execute as TheobaldTheBot if entity @s[tag=!strafe] run tag @s remove tempstrafe