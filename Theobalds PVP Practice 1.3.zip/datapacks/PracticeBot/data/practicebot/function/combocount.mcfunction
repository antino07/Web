execute if entity @s[name=!TheobaldTheBot] if score TheobaldTheBot combo matches 1.. run scoreboard players set TheobaldTheBot combo 0
execute if entity @s[name=!TheobaldTheBot] run scoreboard players remove TheobaldTheBot combo 1
# execute if entity @s[name=!TheobaldTheBot] run say test

execute if entity @s[name=TheobaldTheBot] if score TheobaldTheBot combo matches ..-1 run scoreboard players set TheobaldTheBot combo 0
execute if entity @s[name=TheobaldTheBot] run scoreboard players add TheobaldTheBot combo 1
# execute if entity @s[name=TheobaldTheBot] run say hi


advancement revoke @a only practicebot:hitplayer
