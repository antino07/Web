execute if entity @a[name=TheobaldTheBot,tag=!crit] run tag TheobaldTheBot add addcrit
tag TheobaldTheBot remove crit
execute if entity @a[name=TheobaldTheBot,tag=addcrit] run tag TheobaldTheBot add crit
tag TheobaldTheBot remove addcrit

execute if entity @a[name=TheobaldTheBot,tag=crit] run title @a actionbar [{"text":"CRITTING ","color":"yellow"},{"text":"ON", "color":"green"}]
execute if entity @a[name=TheobaldTheBot,tag=!crit] run title @a actionbar [{"text":"CRITTING ","color":"yellow"},{"text":"OFF", "color":"red"}] 