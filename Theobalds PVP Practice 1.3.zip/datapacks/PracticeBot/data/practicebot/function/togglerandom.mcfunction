execute if entity @a[name=TheobaldTheBot,tag=!random] run tag TheobaldTheBot add addrandom
tag TheobaldTheBot remove random
execute if entity @a[name=TheobaldTheBot,tag=addrandom] run tag TheobaldTheBot add random
tag TheobaldTheBot remove addrandom

execute if entity @a[name=TheobaldTheBot,tag=random] run title @a actionbar [{"text":"RANDOMIZED PLAYSTYLE ","color":"yellow"},{"text":"ON", "color":"green"}]
execute if entity @a[name=TheobaldTheBot,tag=!random] run title @a actionbar [{"text":"RANDOMIZED PLAYSTYLE ","color":"yellow"},{"text":"OFF", "color":"red"}] 