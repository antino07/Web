execute if entity @a[name=TheobaldTheBot,tag=!jreset] run tag TheobaldTheBot add addjreset
tag TheobaldTheBot remove jreset
execute if entity @a[name=TheobaldTheBot,tag=addjreset] run tag TheobaldTheBot add jreset
tag TheobaldTheBot remove addjreset

execute if entity @a[name=TheobaldTheBot,tag=jreset] run title @a actionbar [{"text":"JUMP RESETTING ","color":"yellow"},{"text":"ON", "color":"green"}]
execute if entity @a[name=TheobaldTheBot,tag=!jreset] run title @a actionbar [{"text":"JUMP RESETTING ","color":"yellow"},{"text":"OFF", "color":"red"}] 

execute as TheobaldTheBot if entity @s[tag=jreset] run tag @s add tempjreset
execute as TheobaldTheBot if entity @s[tag=!jreset] run tag @s remove tempjreset