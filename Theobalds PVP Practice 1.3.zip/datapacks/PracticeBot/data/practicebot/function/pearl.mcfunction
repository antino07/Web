execute at TheobaldTheBot at @p[name=!TheobaldTheBot] run player TheobaldTheBot look at ~ 62.6 ~
execute at TheobaldTheBot at @p[name=!TheobaldTheBot,distance=..7] run player TheobaldTheBot look at ~ 61 ~
player TheobaldTheBot hotbar 8
player TheobaldTheBot use once