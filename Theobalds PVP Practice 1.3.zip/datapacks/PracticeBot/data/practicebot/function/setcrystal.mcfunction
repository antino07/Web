tag TheobaldTheBot remove sword
tag TheobaldTheBot add crystal
tag TheobaldTheBird remove naked
player TheobaldTheBot stop
clear @a
effect clear TheobaldTheBot minecraft:resistance
function practicebot:botgear/crystalgear
function practicebot:kits/loadkit
scoreboard players set @a pops 0

title @a actionbar [{"text":"MODE CHANGED TO ","color":"yellow"},{"text":"CRYSTAL", "color":"light_purple"}]
scoreboard objectives setdisplay sidebar pops
scoreboard objectives setdisplay below_name health