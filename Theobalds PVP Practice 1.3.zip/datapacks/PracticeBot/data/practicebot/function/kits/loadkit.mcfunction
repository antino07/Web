execute as @a[name=!TheobaldTheBot] if score @s kit matches 1 run function practicebot:kits/kit1 
execute as @a[name=!TheobaldTheBot] if score @s kit matches 2 run function practicebot:kits/kit2 
execute as @a[name=!TheobaldTheBot] if score @s kit matches 3 run function practicebot:kits/kit3 
execute as @a[name=!TheobaldTheBot] if score @s kit matches 4 run function practicebot:kits/kit4 