fill 33 140 -444 -166 140 -643 minecraft:grass_block
fill 33 139 -643 -166 137 -444 minecraft:dirt