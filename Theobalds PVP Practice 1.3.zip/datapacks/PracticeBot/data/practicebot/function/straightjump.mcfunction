player TheobaldTheBot move
player TheobaldTheBot sprint
player TheobaldTheBot move forward
player TheobaldTheBot jump