player TheobaldTheBot spawn
tag TheobaldTheBot add bot
tag TheobaldTheBot remove sword
tag TheobaldTheBot remove crystal
tag TheobaldTheBot remove strafe
tag TheobaldTheBot remove speed
tag TheobaldTheBot remove stap
function practicebot:setsword
gamemode creative TheobaldTheBot
scoreboard players set TheobaldTheBot difficulty 0