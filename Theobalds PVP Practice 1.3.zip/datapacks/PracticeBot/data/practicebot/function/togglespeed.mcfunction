execute if entity @a[name=TheobaldTheBot,tag=!speed] run tag TheobaldTheBot add addspeed
tag TheobaldTheBot remove speed
execute if entity @a[name=TheobaldTheBot,tag=addspeed] run tag TheobaldTheBot add speed
tag TheobaldTheBot remove addspeed

execute if entity @a[name=TheobaldTheBot,tag=speed] run title @a actionbar [{"text":"BUFFS ","color":"yellow"},{"text":"ON", "color":"green"}]
execute if entity @a[name=TheobaldTheBot,tag=!speed] run title @a actionbar [{"text":"BUFFS ","color":"yellow"},{"text":"OFF", "color":"red"}]