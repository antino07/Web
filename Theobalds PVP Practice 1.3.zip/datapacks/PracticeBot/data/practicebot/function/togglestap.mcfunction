execute if entity @a[name=TheobaldTheBot,tag=!stap] run tag TheobaldTheBot add addstap
tag TheobaldTheBot remove stap
execute if entity @a[name=TheobaldTheBot,tag=addstap] run tag TheobaldTheBot add stap
tag TheobaldTheBot remove addstap

execute if entity @a[name=TheobaldTheBot,tag=stap] run title @a actionbar [{"text":"S TAPPING ","color":"yellow"},{"text":"ON", "color":"green"}]
execute if entity @a[name=TheobaldTheBot,tag=!stap] run title @a actionbar [{"text":"S TAPPING ","color":"yellow"},{"text":"OFF", "color":"red"}] 

execute as TheobaldTheBot if entity @s[tag=stap] run tag @s add tempstap
execute as TheobaldTheBot if entity @s[tag=!stap] run tag @s remove tempstap