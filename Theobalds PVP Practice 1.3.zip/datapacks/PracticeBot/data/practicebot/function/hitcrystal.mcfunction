player TheobaldTheBot sprint
player TheobaldTheBot attack once

execute if score TheobaldTheBot difficulty matches 1 run scoreboard players set TheobaldTheBot hitcd 11
execute if score TheobaldTheBot difficulty matches 2 run scoreboard players set TheobaldTheBot hitcd 22
execute if score TheobaldTheBot difficulty matches 3 run scoreboard players set TheobaldTheBot hitcd 22
execute if score TheobaldTheBot difficulty matches 4.. run scoreboard players set TheobaldTheBot hitcd 11
