tag @a remove norefill
# tag @a[name=TheobaldTheBird,nbt={SelectedItem:{id:"minecraft:totem_of_undying"}}] add norefill
# tag @a[name=TheobaldTheBird,nbt={SelectedItem:{id:"minecraft:tnt_minecart"}}] add norefill
tag @a[name=TheobaldTheBird,nbt={SelectedItem:{id:"minecraft:bucket"}}] add norefill
# tag @a[name=TheobaldTheBird,nbt={SelectedItem:{id:"minecraft:splash_potion"}}] add norefill

item modify entity @a[tag=!norefill] weapon.mainhand practicebot:refill