effect give @a[tag=!crystal] fire_resistance 1 1 true
effect give @a[tag=!crystal] resistance 1 5 true
effect give @a[tag=!crystal] saturation 1 255 true