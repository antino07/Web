execute store result score TheobaldTheBot food run data get entity TheobaldTheBot foodLevel
execute as TheobaldTheBot if score @s food matches ..16 run effect give @s minecraft:saturation 1 1 true

execute if score TheobaldTheBot difficulty matches 0 run function practicebot:look
execute as TheobaldTheBot if score @s difficulty matches 0 run function practicebot:refilltotem
execute as TheobaldTheBot if score @s shieldcd matches 1.. run scoreboard players remove @s shieldcd 1

execute if score TheobaldTheBot difficulty matches 1.. run function practicebot:d1
execute as TheobaldTheBot if score @s difficulty matches 0..1 if entity @s[tag=shield] if score @s shieldcd matches 0 run player TheobaldTheBot hotbar 9
execute as TheobaldTheBot if score @s difficulty matches 0..1 if entity @s[tag=shield] unless entity @s[tag=refilling] run player TheobaldTheBot use continuous

execute at @a[name=!TheobaldTheBot,x=0,y=0,z=0,distance=..300] run fill ~-5 71 ~-5 ~5 71 ~5 moving_piston replace air 
item modify entity TheobaldTheBot weapon.mainhand practicebot:refill