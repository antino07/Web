title @a times 0s 10s 3s
title @a subtitle [{"text":"INSTALL ","color":"dark_red"},{"text":"CARPET MOD ","color":"red"},{"text":"TO PLAY","color":"dark_red"}]
title @a title [{"text":"MISSING CARPET MOD","color":"yellow"}]