execute at TheobaldTheBot at @p[name=!TheobaldTheBot] run teleport TheobaldTheBot ^ ^ ^-5
execute at TheobaldTheBot run teleport TheobaldTheBot ~ 61 ~